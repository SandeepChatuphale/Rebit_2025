import { Injectable } from '@angular/core';
import { Customer } from '../dto/Customer';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  customers : Customer[] = []

  constructor() { }

  register(c:Customer)
  {
    this.customers.push(c)
  }

  login(c:Customer) : boolean
  {
    if(c.email == 'admin' && c.password == 'admin')
      {
        return true
      }
      else
       return false;
  }
}
