import { Injectable } from '@angular/core';
import { Account } from '../dto/Account';

@Injectable({
  providedIn: 'root'
})
export class AccountService {

  accounts :Account[] = []
  constructor() { 
    let a1 = new Account(1,5000,'ajay')
      this.accounts.push(a1)

      let a2 = new Account(2,4000,'amit')
      this.accounts.push(a2)
  }

  save(a:Account)
  {
    this.accounts.push(a)
  }
}