import { Component } from '@angular/core';
import { Account } from '../dto/Account';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AccountService } from '../service/account.service';


@Component({
  selector: 'app-accounts',
  standalone: true,
  imports: [CommonModule,FormsModule],
  templateUrl: './accounts.component.html',
  styleUrl: './accounts.component.css'
})
export class AccountsComponent {

    accounts : Account[] = [];
    copyAccounts = this.accounts;

    flag : boolean= false
    message : string = '';

    serachCriteria : number = 0 ;

    successStyle = {color:'green',fontStyle:'italic'}
    errorStyle = {color:'red'}
    
    //DI - injecting object of service
    constructor(private s:AccountService){ 
      this.accounts = s.accounts;
    }

    sortAccounts()
    {
      this.copyAccounts =  this.accounts.filter(a => a.balance > this.serachCriteria)
    }

    //invoked when user clicks on button
    //event binding
    deleteAccount(accN:number)
    {
    const status = confirm('are you sure?')
    if(status){
      this.accounts =  this.accounts.filter(a => a.accountNumber != accN)
      this.message = 'Account Deleted with account Number ' + accN
      this.flag = status
    }
    else{
      this.message = 'Deletetion Cancelled'
    }
    }
}
