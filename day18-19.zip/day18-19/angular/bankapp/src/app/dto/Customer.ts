export class Customer{
    constructor(public email:string,public password:string){}
}