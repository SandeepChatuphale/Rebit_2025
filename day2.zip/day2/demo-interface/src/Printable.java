
public interface Printable {
	void print();
	void printType();
}


