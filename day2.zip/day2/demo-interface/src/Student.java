
public class Student implements Printable {

	@Override
	public void print() {
	}

	@Override
	public void printType() {
	}
}
