

public class DemoInterface {

	public static void main(String[] args) {

		Printable p;//reference
		
		//interface Object can't be created
		//bcz interface is abstract by default
		//p = new Printable();//error
		
		
		
		//reference of interface can refer to 
		//object of any class
		//if that class is implementing the interface
		
		p = new Employee();
		
		p = new Student();
		
		
		
		
		
	}

}
