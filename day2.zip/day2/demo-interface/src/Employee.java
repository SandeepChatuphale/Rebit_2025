
//Employee MUST override all methods of Printable
//otherwise compiler complains
public class Employee implements Printable{

	@Override
	public void print() {
	}

	@Override
	public void printType() {
	}

}
