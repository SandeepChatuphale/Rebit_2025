package org.rebit.bankapp.service.impl;

import java.util.List;

import org.rebit.bankapp.entity.Account;
import org.rebit.bankapp.factory.BeanFactory;
import org.rebit.bankapp.repository.AccountRepository;
import org.rebit.bankapp.repository.impl.AccountJpaRepositoryImpl;
import org.rebit.bankapp.service.AccountService;

public class AccountServiceImpl implements AccountService {

	//coding to interface
	private AccountRepository repo;
	
	//constructor injection
	public AccountServiceImpl(AccountRepository r) {
		
		//approach-1
		//object creation of repo leads to "tight coupling"
		//hence should be done by BeanFactrory
		//repo = new AccountJpaRepositoryImpl();
		
		
		//approch-2
		//BeanFactory factory = new BeanFactory();
		//repo = factory.getAccountRepo();
		
		
		//approach-3
		repo = r;
	}
	
	@Override
	public Account register(Account a) {
		return repo.save(a);
	}

	@Override
	public Account searchByAccountNumber(int accountNumber) {
		return repo.findById(accountNumber);
	}

	@Override
	public void deleteByAccountnumber(int accountNumber) {
		// TODO Auto-generated method stub
		repo.deleteById(accountNumber);
		
	}

	@Override
	public List<Account> searchAll() {
		return repo.findAll();
	}
}
