package org.rebit.bankapp;

import java.util.List;

import org.rebit.bankapp.entity.Account;
import org.rebit.bankapp.factory.BeanFactory;
import org.rebit.bankapp.service.AccountService;

public class AccountApplication {

	public static void main(String[] args) {
		
		//responsible for objection
		BeanFactory factory = new BeanFactory();

		//declaration of reference type
		//coding to interface helps for loose coupling
		//interfaces are used as contract
		AccountService service;
		
		//creating object and assigning it to repo
		service = factory.getService();
		
		//jdk 15 
		//Text block
		//this is used for multi-line string
		String menu = """
					1. Register
					2. Find by id
					3. delete by Account Number
					4. search All
					-1. Exit
				""";
		System.out.println(menu);
		
		int option = 4;
		
		switch(option)
		{
		case 1:
			Account a = new Account(1,5000,"sandeep");
			//invoking method of service
			service.register(a);
			System.out.println("Thank you for registration");
			break;
		case 2:
			Account foundAccount = service.searchByAccountNumber(1);
			System.out.println("Account details are " + foundAccount);
			break;
		case 3:
			service.deleteByAccountnumber(1);
			
			break;
		case 4:
			List<Account> accounts = service.searchAll();
			System.out.println(accounts);
			break;
		case -1:
			System.out.println("Thank you visit again");
			break;
		}
				
	}

}
