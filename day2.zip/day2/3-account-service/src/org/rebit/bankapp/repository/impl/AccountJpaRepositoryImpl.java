package org.rebit.bankapp.repository.impl;

import org.rebit.bankapp.entity.Account;
import org.rebit.bankapp.repository.AccountRepository;

public class AccountJpaRepositoryImpl implements AccountRepository {

	public Account save(Account a)
	{
		return a;
	}
	
	public Account findById(int accountNumber) {
		Account a = new Account(1, 5000, "Me");
		return a;
	}
}
