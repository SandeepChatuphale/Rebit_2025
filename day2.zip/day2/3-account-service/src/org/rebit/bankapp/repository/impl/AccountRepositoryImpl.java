package org.rebit.bankapp.repository.impl;

import org.rebit.bankapp.entity.Account;
import org.rebit.bankapp.repository.AccountRepository;

//responsible for talking to data-store (DB)
//provides CRUD operation for Account entity
public class AccountRepositoryImpl implements AccountRepository{
	
	//C - save
	public Account save(Account a)
	{
		System.out.println("Saving Account in DB ");
		return a;
	}
	
	//R - READ
	public Account findById(int accountNumber) {
		
		Account a = new Account(1, 5000, "Me");
		return a;
	}
	
	
	
	
}
