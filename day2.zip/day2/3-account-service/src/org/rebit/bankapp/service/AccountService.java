package org.rebit.bankapp.service;

import org.rebit.bankapp.entity.Account;

public interface AccountService {

	Account register(Account a);
}
