package org.rebit.bankapp.service.impl;

import org.rebit.bankapp.entity.Account;
import org.rebit.bankapp.repository.AccountRepository;
import org.rebit.bankapp.service.AccountService;

public class AccountServiceImpl implements AccountService {

	//coding to interface
	private AccountRepository repo;
	
	@Override
	public Account register(Account a) {
		return repo.save(a);
	}

}
