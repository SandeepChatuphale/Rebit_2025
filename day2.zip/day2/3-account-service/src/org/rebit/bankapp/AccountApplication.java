package org.rebit.bankapp;

import org.rebit.bankapp.entity.Account;
import org.rebit.bankapp.factory.BeanFactory;
import org.rebit.bankapp.repository.AccountRepository;
import org.rebit.bankapp.repository.impl.AccountJpaRepositoryImpl;
import org.rebit.bankapp.repository.impl.AccountRepositoryImpl;

public class AccountApplication {

	public static void main(String[] args) {
		
		//responsible for objection
		BeanFactory factory = new BeanFactory();

		//declaration of reference type
		//coding to interface helps for loose coupling
		//interfaces are used as contract
		AccountRepository repo;
		
		//creating object and assigning it to repo
		repo = factory.getAccountRepo();
		
		//AccountJpaRepositoryImpl repo = new AccountJpaRepositoryImpl();
		
		Account a = new Account(1,5000,"sandeep");
		repo.save(a);	//invoking method of repo to save object to DB
	
		Account foundAccount = repo.findById(1);
		

		
		
		
		//System.out.println(a.accountNumber);
		//System.out.println(a.getAccountNumber());
	
		//System.out.println(a.balance);
		//System.out.println(a.getBalance());
	
		//a.accountNumber = -1;
	}

}
