package org.rebit.bankapp.factory;

import org.rebit.bankapp.repository.impl.AccountRepositoryImpl;

//object creation
public class BeanFactory {

	//creating and returning object of
	//AccountRepositoryImpl
	public AccountRepositoryImpl getAccountRepo()
	{
		//creating object
		AccountRepositoryImpl repo = new AccountRepositoryImpl();
		
		//returning object 
		return repo;
	}
}
