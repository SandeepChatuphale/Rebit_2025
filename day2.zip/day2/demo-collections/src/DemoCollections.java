import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DemoCollections {

	public static void main(String[] args) {

		List<String> cities = new ArrayList<>();

		cities.add("Mumbai");
		cities.add("Pune");
		cities.add("Banglore");
		cities.add("Delhi");

		System.out.println("Before");
		System.out.println(cities);
		
		//Collections is a class with utility method
		//sort is method of Collections class 
		//which sort given List
		Collections.sort(cities);
		
		System.out.println("After");
		System.out.println(cities);
	}
}