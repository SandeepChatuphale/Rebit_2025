import java.util.ArrayList;
import java.util.List;

public class DemoArrayList {

	public static void main(String[] args) {
		
		//<> - this is generics symbol
		//using generics we specify what type of element is
		//allowed in collection 
		List<String> cities = new ArrayList<>();
		
		cities.add("Mumbai");
		cities.add("Pune");
		cities.add("Banglore");
		cities.add("Delhi");
		cities.add("Mumbai");//duplicate is allowed
		
		
		System.out.println(cities);
		
		//number of elements
		System.out.println(cities.size());
		
		//element at index 2 - element starts with 0
		System.out.println(cities.get(2));
		
		//remove element at given index
		cities.remove(1);
		
		//add element at given index
		cities.add(2, "Chennai");
		
		
		//remove all elements
		cities.clear();
		
		System.out.println(cities);
	}
}
