import java.util.HashSet;
import java.util.Set;

public class DemoHashSet {

	public static void main(String[] args) {

		Set<String> cities = new HashSet<>();
		
		cities.add("Mumbai");
		cities.add("Pune");
		cities.add("Delhi");
		cities.add("Mumbai");//no error BUT does not add
							//as duplicates are NOT allowed
		
		
		System.out.println(cities);
	
		//Set does NOT support any index based method
		
		System.out.println(cities.size());
		
		cities.remove("Pune");//remove given element
		
		System.out.println(cities);
		
		cities.clear();
		
	}

}
