package org.rebit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoWebSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
