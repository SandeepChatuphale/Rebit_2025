package org.rebit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.client.RestClient;

@SpringBootApplication
public class DemoWebSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoWebSpringbootApplication.class, args);
		
		String baseUrl = "http://localhost:8080";
		RestClient rt = RestClient.create(baseUrl);
		
		
		//case 1 - fetching by accountNumber
		String responseData =rt.get()
		  .uri("/account/2")
		  .retrieve()
		  .toEntity(String.class)
		  .getBody();
		
		System.out.println(responseData);
		
	}

}
