package org.rebit.crm;

import org.rebit.crm.dto.CustomerDto;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClient;

@SpringBootApplication
public class CustomerApplication {

	public static void main(String[] args) {
		
		SpringApplication.run(CustomerApplication.class, args);
		
		RestClient rt = RestClient.create("http://localhost:8080");
		
		int option = 1;
		
		switch (option) {
		case 1: {
			
			ResponseEntity<CustomerDto> res = rt.get()
			  .uri("/customer?email=sandeep@gmail.com")
			  .retrieve()
			  .toEntity(CustomerDto.class);
			
			if(res.getStatusCode() == HttpStatus.OK)
			{
				CustomerDto data = res.getBody();
				System.out.println(data.email());
				System.out.println(data.password());
				System.out.println(data.roles());
			}
			
			
			
			break;
		}
		default:
			throw new IllegalArgumentException("Unexpected value: " + option);
		}
		
	}

}
