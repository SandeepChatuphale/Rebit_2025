package org.rebit.crm.service.impl;

import java.util.List;
import java.util.Optional;

import org.rebit.crm.entity.Customer;
import org.rebit.crm.exception.CustomerAlreadyRegisteredException;
import org.rebit.crm.exception.CustomerNotFoundException;
import org.rebit.crm.repository.CustomerRepository;
import org.rebit.crm.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerServiceImpl implements CustomerService {

	
	@Autowired
	private CustomerRepository repo ;
	
	
	/**
	 * responsible for registering a customer
	 * after successful registration unique id should be assigned
	 * to each customer
	 * @throws CustomerAlreadyRegisteredException
	 * @author Sandeep
	 * @return Customer
	 * @param Customer newCustomer
	 * 
	 */
	@Override
	public Customer register(Customer newCustomer) throws CustomerAlreadyRegisteredException {
		try 
		{
			searchByEmail(newCustomer.getEmail());
			//if there is no exception which means customer already exists
			//then throw CustomerAlreadyRegisteredException
			throw new CustomerAlreadyRegisteredException("Customer Already Registered with " + newCustomer.getEmail());
		}
		catch (CustomerNotFoundException e) {
			
			newCustomer.setRoles(List.of("ROLE_USER"));//assigning USER ROLE to customer
			Customer registeredCustomer = repo.save(newCustomer);
			registeredCustomer.setPassword(null);
			return registeredCustomer;
		}		
	}

	@Override
	public Customer searchByEmail(String email) throws CustomerNotFoundException {
		
		Optional<Customer> o = repo.findByEmail(email);
		
		if(o.isEmpty())
		{
			throw new CustomerNotFoundException();
		}
		
		return o.get();
	}
}
