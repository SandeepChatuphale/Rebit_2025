package org.rebit.crm;

import org.rebit.crm.entity.Customer;
import org.rebit.crm.exception.CustomerAlreadyRegisteredException;
import org.rebit.crm.exception.CustomerNotFoundException;
import org.rebit.crm.factory.BeanFactory;
import org.rebit.crm.service.CustomerService;

public class CustomerApplication {

	public static void main(String[] args) {
		
		
		BeanFactory factory = new BeanFactory();
		
		CustomerService service = factory.getCustomerService();
		
		
		Customer c = new Customer("abc@gmail.com","abc");
		try 
		{
			service.register(c);
		}
		catch (CustomerAlreadyRegisteredException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
		Customer foundCustomer;
		try
		{
			foundCustomer = service.searchByEmail("abcd@gmail.com");
			System.out.println(foundCustomer);
		}
		catch (CustomerNotFoundException e) {
			e.printStackTrace();
		}
		

	}

}
