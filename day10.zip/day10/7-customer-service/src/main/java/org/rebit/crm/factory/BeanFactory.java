package org.rebit.crm.factory;

import org.rebit.crm.repository.CustomerRepository;
import org.rebit.crm.repository.impl.CustomerJpaRepositoryImpl;
import org.rebit.crm.service.CustomerService;
import org.rebit.crm.service.impl.CustomerServiceImpl;

import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class BeanFactory {
	private CustomerRepository repo;
	private CustomerService service;
	private EntityManagerFactory f;
	//constructor
	public BeanFactory() {
		f = Persistence.createEntityManagerFactory("crm");
		repo = new CustomerJpaRepositoryImpl(f);
		service = new CustomerServiceImpl(repo);
	}
	public CustomerRepository getCustomerRepository(){
		return repo;
	}
	public CustomerService getCustomerService() {
		return service;
	}
	
	
	
	
}
