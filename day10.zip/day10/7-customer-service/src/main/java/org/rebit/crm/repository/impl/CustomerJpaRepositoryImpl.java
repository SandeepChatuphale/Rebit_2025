package org.rebit.crm.repository.impl;

import org.rebit.crm.entity.Customer;
import org.rebit.crm.repository.CustomerRepository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.TypedQuery;

public class CustomerJpaRepositoryImpl implements CustomerRepository {

	private EntityManagerFactory factory;

	//constructor injection
	public CustomerJpaRepositoryImpl(EntityManagerFactory f) {
		factory = f;
	}
	
	@Override
	public Customer save(Customer newCustomer) {
		EntityManager em = factory.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		
		em.persist(newCustomer);
		
		tx.commit();
		em.close();
		
		return newCustomer;
	}

	@Override
	public Customer findByEmail(String email) {

		EntityManager em = factory.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();

		//find by email
		//JPQL - jakarta persistence query language
		//in jpql we deal with Entity class and its fields
		String jpql = "FROM Customer AS c WHERE c.email = :e";
		TypedQuery<Customer> query = em.createQuery(jpql, Customer.class);
		query.setParameter("e", email);//setting parameter
		Customer foundCustomer = query.getSingleResult();
		
		tx.commit();
		em.close();
		
		return foundCustomer;
	}

}
