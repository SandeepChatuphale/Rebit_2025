package org.rebit.crm.repository;

import org.rebit.crm.entity.Customer;

public interface CustomerRepository {

	Customer save(Customer newCustomer);
	Customer findByEmail(String email);
}
