package org.rebit.email.service.impl;

import org.rebit.email.entity.Email;
import org.rebit.email.repository.EmailRepository;
import org.rebit.email.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmailServiceImpl implements EmailService{

	@Autowired
	private EmailRepository repo;
	
	@Override
	public Email sendEmail(Email e) {
		return repo.save(e);
	}

}
