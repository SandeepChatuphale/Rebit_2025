package org.rebit.email.service;

import org.rebit.email.entity.Email;

public interface EmailService {
	
	Email sendEmail(Email e);
}
