package org.rebit.bankapp.restclient;

import org.rebit.bankapp.request.EmailRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

@Component
public class EmailRestClientImpl implements EmailRestClient{

	@Override
	public boolean sendEmail(EmailRequest req) {
		
		ResponseEntity<EmailRequest> res = 
				   RestClient.create("http://localhost:8084")
				  .post()
				  .uri("/email")
				  .body(req)
				  .retrieve()
				  .toEntity(EmailRequest.class);
		
		if(res.getStatusCode() == HttpStatus.CREATED)
			return true;
	
		return false;
	}

}
