package org.rebit.bankapp.view.impl;

public class AccountViewImpl {

	public void printMessage(String msg)
	{
		System.out.println(msg);
	}
}
