package org.rebit.bankapp.request;

public record EmailRequest(String receiver,String subjectMsg) {

}
