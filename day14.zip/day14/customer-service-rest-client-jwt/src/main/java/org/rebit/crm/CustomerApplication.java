package org.rebit.crm;

import org.rebit.crm.dto.CustomerDto;
import org.rebit.crm.response.JwtToken;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClient;

@SpringBootApplication
public class CustomerApplication {

	public static void main(String[] args) {
		
		SpringApplication.run(CustomerApplication.class, args);
		
		RestClient rt = RestClient.create("http://localhost:8080");
		
		
		int option = 1;
		
		
		switch (option) {
		case 1: {
			
			CustomerDto req = new CustomerDto("me@gamil.com","me",null);
			
			ResponseEntity<JwtToken> entity = rt.post().uri("/customer/authentication")
			  .body(req)
			  .retrieve()
			  .toEntity(JwtToken.class);
			
			if(entity.getStatusCode() == HttpStatus.OK)
			{
				String token=entity.getBody().getJwttoken();

				ResponseEntity<CustomerDto> res = rt.get()
				  .uri("/customer?email=me@gamil.com")
				  .header(HttpHeaders.AUTHORIZATION, "Bearer " + token)
				  .retrieve()
				  .toEntity(CustomerDto.class);
				
				if(res.getStatusCode() == HttpStatus.OK)
				{
					CustomerDto data = res.getBody();
					System.out.println(data.email());
					System.out.println(data.password());
					System.out.println(data.roles());
				}		
			}
			else
			{
				System.out.println("");
			}
					break;
		}
			case 2:
				CustomerDto d= new CustomerDto("me@gamil.com", "me", null);
				ResponseEntity<CustomerDto> entity = rt.post()
				  .uri("/customer")
				  .body(d)
				  .retrieve()
				  .toEntity(CustomerDto.class);
				
				System.out.println(entity.getStatusCode());
				System.out.println(entity.getBody().roles());
				break;
				
		
		default:
			throw new IllegalArgumentException("Unexpected value: " + option);
		}
		
	}

}
