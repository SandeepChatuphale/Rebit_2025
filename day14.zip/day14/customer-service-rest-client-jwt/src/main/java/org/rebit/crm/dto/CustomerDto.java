package org.rebit.crm.dto;

import java.util.List;

public record CustomerDto(String email,String password,List<String> roles) {	
}
