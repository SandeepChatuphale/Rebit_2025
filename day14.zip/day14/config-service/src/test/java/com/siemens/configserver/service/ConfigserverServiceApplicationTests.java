package com.siemens.configserver.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigserverServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
