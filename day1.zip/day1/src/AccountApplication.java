class AccountApplication{
	public static void main(String[] args){
		
		//create object (instance of class)
		//how?
		//class_name reference_name = new class_name();
		Account a = new Account();
		
 	}
}