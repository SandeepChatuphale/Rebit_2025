class HelloWorld
{
	//main mathod
 	public static void main(String[] args){
		System.out.println("Hello - REBIT");	//printing on console
 	}
}

