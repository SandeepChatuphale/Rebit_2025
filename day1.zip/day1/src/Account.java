class Account{
	
	//instance variables OR fields
	//data_type variable_name
	int accountNumber;
	float balance;
	
}