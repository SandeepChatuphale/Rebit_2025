package org.rebit.bankapp.entity;

public class Account {
	//instance variables
	//assigned with default values based on data type
	private int accountNumber;
	private float balance;
	private String owner;
	
	//parameterized constructor
	public Account(int accountNumber, float balance, String owner) {
		super();
		this.accountNumber = accountNumber;
		this.balance = balance;
		this.owner = owner;
	}
	
	public int getAccountNumber() {
		return accountNumber;
	}
	
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
}
