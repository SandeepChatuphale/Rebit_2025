package org.rebit.bankapp;

import org.rebit.bankapp.entity.Account;
import org.rebit.bankapp.repository.impl.AccountJpaRepositoryImpl;
import org.rebit.bankapp.repository.impl.AccountRepositoryImpl;

public class AccountApplication {

	public static void main(String[] args) {
		
		
		int i = 19;//local variable
		
		
		
		
	
		Account a = new Account(1,5000,"sandeep");
		AccountRepositoryImpl repo = new AccountRepositoryImpl();
		//AccountJpaRepositoryImpl repo = new AccountJpaRepositoryImpl();
		
		repo.save(a);	//invoking method of repo to save object to DB
	
		Account foundAccount = repo.findById(1);
		
		
		
		
		
		
		
		//System.out.println(a.accountNumber);
		//System.out.println(a.getAccountNumber());
	
		//System.out.println(a.balance);
		//System.out.println(a.getBalance());
	
		//a.accountNumber = -1;
	}

}
