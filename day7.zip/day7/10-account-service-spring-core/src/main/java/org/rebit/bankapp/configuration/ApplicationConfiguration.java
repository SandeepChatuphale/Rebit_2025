package org.rebit.bankapp.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

@Configuration
//scanning for stereo type annotations in given 
//package and its subpackages
@ComponentScan("org.rebit.bankapp")

//read properties file and load all properties in memory
@PropertySource("classpath:application.properties")
public class ApplicationConfiguration {

	//in this class we should define methods returning
	//objects of built-in classes
	//annotate these methods with @Bean
	//so that those objects are registered as spring bean
	@Bean
	EntityManagerFactory getFactory()
	{
		return Persistence.createEntityManagerFactory("bankapp");
	}
}
