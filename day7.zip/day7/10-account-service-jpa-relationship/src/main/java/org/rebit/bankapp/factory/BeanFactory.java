package org.rebit.bankapp.factory;

import org.rebit.bankapp.repository.AccountRepository;
import org.rebit.bankapp.repository.impl.AccountJpaRepositoryImpl;
import org.rebit.bankapp.service.AccountService;
import org.rebit.bankapp.service.impl.AccountServiceImpl;

import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

//object creation
public class BeanFactory {

	//creating and returning object of
	//AccountRepositoryImpl
	public AccountRepository getAccountRepo(){
		
		//creating object
		AccountRepository repo ;
		//repo = new AccountRepositoryImpl();
		EntityManagerFactory f = Persistence.createEntityManagerFactory("bankapp");
		repo = new AccountJpaRepositoryImpl(f);
		//returning object 
		return repo;
	}
	public AccountService getService()
	{
		AccountService service = 
		new AccountServiceImpl(getAccountRepo());
		return service;
	}	
}
