package org.rebit.bankapp.exception;

//creating custom Exception by extending it from Exception class
//extends is keyword used to create subclass
public class AccountNotFoundException extends Exception {

}
