package org.rebit.bankapp.repository.impl;

import java.util.List;
import java.util.Optional;

import org.rebit.bankapp.entity.Account;
import org.rebit.bankapp.repository.AccountRepository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.TypedQuery;

public class AccountJpaRepositoryImpl implements AccountRepository {

	private EntityManagerFactory factory;
	
	public AccountJpaRepositoryImpl(EntityManagerFactory f) {
		factory = f;
	}
	
	public Account save(Account a)
	{
		EntityManager em = factory.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		em.persist(a);
		tx.commit();
		em.close();
		return a;
	}
	
	public Optional<Account> findById(int accountNumber) {
		
		EntityManager em = factory.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		Account foundAccount = em.find(Account.class, accountNumber);
		tx.commit();
		em.close();
		return Optional.of(foundAccount);
	}

	@Override
	public void deleteById(int accountNumber) {

		EntityManager em = factory.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
	
		em.remove(em.find(Account.class, accountNumber));
		tx.commit();
		em.close();		
	}

	@Override
	public List<Account> findAll() {
		
		EntityManager em = factory.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		
		//Find All
		String jpql = "FROM Account";
		TypedQuery<Account> query = em.createQuery(jpql, Account.class);
		List<Account> accounts = query.getResultList();
		
		tx.commit();
		em.close();
		
		return accounts;
	}
}







