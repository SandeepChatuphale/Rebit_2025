package org.rebit.bankapp.repository.impl;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;
import java.util.Properties;

import org.rebit.bankapp.entity.Account;
import org.rebit.bankapp.repository.AccountRepository;

//responsible for talking to data-store (DB)
//provides CRUD operation for Account entity
public class AccountRepositoryImpl implements AccountRepository{

	private Connection con;
	
	public AccountRepositoryImpl() {
	
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bankapp_db","root","root");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	//C - save
	public Account save(Account a)
	{
		PreparedStatement pstmt ;
		try {
			pstmt = con.prepareStatement("INSERT INTO tbl_account VALUES(?,?,?)");
			pstmt.setInt(1, a.getAccountNumber());
			pstmt.setDouble(2, a.getBalance());
			pstmt.setString(3,a.getOwner());
			
			int numberOfRowsUpdated = pstmt.executeUpdate();
			
			if(numberOfRowsUpdated == 1) {
				return a;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return a;
	}
	
	//R - READ
	public Optional<Account> findById(int accountNumber) {
		PreparedStatement pstmt = null;
		try
		{
			pstmt = con.prepareStatement("SELECT * FROM tbl_account WHERE accountNumber = ?");
			pstmt.setInt(1, accountNumber);
			ResultSet rs = pstmt.executeQuery();
			
			//checking if record present with given accountNumber
			if(rs.next()) {
			Account foundAccount = new Account(rs.getFloat(2),rs.getString(3));
			//if yes return Optional of found Account
			return Optional.of(foundAccount);
			}
			else
				return Optional.empty();
		}
		catch (SQLException e) {
		}
		return Optional.empty();
	}

	@Override
	public void deleteById(int id) {
	}

	@Override
	public List<Account> findAll() {
		return null;
	}
	
	
	
	
}
