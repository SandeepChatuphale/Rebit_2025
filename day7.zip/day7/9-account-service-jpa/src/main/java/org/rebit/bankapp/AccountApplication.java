package org.rebit.bankapp;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import org.rebit.bankapp.entity.Account;
import org.rebit.bankapp.exception.AccountNotFoundException;
import org.rebit.bankapp.factory.BeanFactory;
import org.rebit.bankapp.service.AccountService;

public class AccountApplication {

	public static void main(String[] args) {

		Scanner sc = null;
		try 
		{
			// used to take I/P from user
			sc = new Scanner(System.in);

			// responsible for objection
			BeanFactory factory = new BeanFactory();

			// declaration of reference type
			// coding to interface helps for loose coupling
			// interfaces are used as contract
			AccountService service;

			// creating object and assigning it to repo
			service = factory.getService();

			// jdk 15
			// Text block
			// this is used for multi-line string
			String menu = """
						1. Register
						2. Find by id
						3. delete by Account Number
						4. search All
						5. Search all for Eligible for Credit card
						6. Search All Owners maintaining Balance
						7. Total Balance
						-1. Exit
					""";
			System.out.println(menu);
			System.out.println("Please Enter choice....");

			int option = sc.nextInt();

			switch (option) {
			case 1:
				Account a = new Account(5000, "ajay");
				// invoking method of service
				Account registeredAccount = service.register(a);
			System.out.println("Thank you for registration. Your id is " 
				+ registeredAccount.getAccountNumber());
				break;
			case 2:
				Account foundAccount;
				try 
				{
					foundAccount = service.searchByAccountNumber(1);
					System.out.println("Account details are " + foundAccount);
				}
				catch (AccountNotFoundException e) {
					e.printStackTrace();
				}
				
				break;
			case 3:
				service.deleteByAccountnumber(1);

				break;
			case 4:
				List<Account> accounts = service.searchAll();
				System.out.println(accounts);
				break;
			case 5:
				accounts = service.searchAllEligibleForCreditCard(4000);
				break;
			case 6:
				List<String> owners = service.searchAllOwnersMaintainingBalance(4000);
				break;
			case 7:
				double totalBalance = service.calculateTotalBalance();
				break;
			case -1:
				System.out.println("Thank you visit again");
				break;
			}
		} 
		catch (InputMismatchException e) {
			System.out.println("Enter choice in integer format");
		}
		finally {
			sc.close();//closing the resource
		}
		
	}
}
