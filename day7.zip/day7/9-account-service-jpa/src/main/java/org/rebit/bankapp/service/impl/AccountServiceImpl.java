package org.rebit.bankapp.service.impl;

import java.util.List;
import java.util.Optional;

import org.rebit.bankapp.entity.Account;
import org.rebit.bankapp.exception.AccountNotFoundException;
import org.rebit.bankapp.factory.BeanFactory;
import org.rebit.bankapp.repository.AccountRepository;
import org.rebit.bankapp.repository.impl.AccountJpaRepositoryImpl;
import org.rebit.bankapp.service.AccountService;

public class AccountServiceImpl implements AccountService {
	//coding to interface
	private AccountRepository repo;
	
	//constructor injection
	public AccountServiceImpl(AccountRepository r) {
		
		//approach-1
		//object creation of repo leads to "tight coupling"
		//hence should be done by BeanFactrory
		//repo = new AccountJpaRepositoryImpl();
		
		
		//approch-2
		//BeanFactory factory = new BeanFactory();
		//repo = factory.getAccountRepo();
		
		
		//approach-3
		repo = r;
	}
	
	@Override
	public Account register(Account a) {
		return repo.save(a);
	}

	@Override
	public Account searchByAccountNumber(int accountNumber) throws AccountNotFoundException {
		Optional<Account> o = repo.findById(accountNumber);
	
		//if account NOT found 
		if(o.isEmpty())
		{
			//throw Customexception
			AccountNotFoundException ex = new AccountNotFoundException();
			throw ex;
		}
		return o.get();
	}

	@Override
	public void deleteByAccountnumber(int accountNumber) {
		// TODO Auto-generated method stub
		repo.deleteById(accountNumber);
		
	}

	@Override
	public List<Account> searchAll() {
		return repo.findAll();
	}

	@Override
	public List<Account> searchAllEligibleForCreditCard(int amount) {
		return this.repo.findAll().stream()
						   .filter(acc -> acc.getBalance() > amount)
						   .toList();
	}

	@Override
	public List<String> searchAllOwnersMaintainingBalance(int amount) {
		return repo.findAll()
				   .stream()
				   .filter(acc -> acc.getBalance() > amount)
				   .map(acc -> acc.getOwner())
				   .toList();
	}

	//bank is interesetd is knowing total balance of all accounts
	//for lending loan purpose
	@Override
	public double calculateTotalBalance() {
		return repo.findAll()
				   .stream()
				   .mapToDouble(acc -> acc.getBalance())
				   .sum();
	}
}
