package org.rebit.bankapp.factory;

import org.rebit.bankapp.repository.AccountRepository;
import org.rebit.bankapp.repository.impl.AccountJpaRepositoryImpl;
import org.rebit.bankapp.repository.impl.AccountRepositoryImpl;
import org.rebit.bankapp.service.AccountService;
import org.rebit.bankapp.service.impl.AccountServiceImpl;

//object creation
public class BeanFactory {

	//creating and returning object of
	//AccountRepositoryImpl
	public AccountRepository getAccountRepo(){
		
		
		//creating object
		AccountRepository repo ;
		repo = new AccountRepositoryImpl();	
		//repo = new AccountJpaRepositoryImpl();
		//returning object 
		return repo;
	}
	public AccountService getService()
	{
		AccountService service = 
		new AccountServiceImpl(getAccountRepo());
		return service;
	}	
}
