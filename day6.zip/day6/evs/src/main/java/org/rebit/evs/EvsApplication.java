package org.rebit.evs;

public class EvsApplication {

	public static void main(String[] args) {
		System.out.println("In EvsApplication");
	}
}
