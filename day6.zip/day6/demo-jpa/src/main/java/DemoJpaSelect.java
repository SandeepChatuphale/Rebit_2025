import org.rebit.bankapp.entity.Account;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

public class DemoJpaSelect {

	public static void main(String[] args) {

		
		//step1- create an object of EntityManagerFactory
		EntityManagerFactory factory = null;
		factory = Persistence.createEntityManagerFactory("bankapp");
		
		//step2- create an object of EntityManager
		//responsible for DB interaction
		//by providing different methods
		EntityManager em = factory.createEntityManager();
		
		//step3- create an object of EntityTransaction
		//responsible for maintaining transaction
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		
		//step4 - perform DB operation
		Account foundAccount = em.find(Account.class,1);
		
		//step5 - commit/rollback transaction
		tx.commit();
		
		//step - close resources
		em.close();
		factory.close();

	}

}
