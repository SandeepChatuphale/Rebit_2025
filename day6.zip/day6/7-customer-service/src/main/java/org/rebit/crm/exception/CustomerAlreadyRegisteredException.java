package org.rebit.crm.exception;

public class CustomerAlreadyRegisteredException extends Exception {

}
