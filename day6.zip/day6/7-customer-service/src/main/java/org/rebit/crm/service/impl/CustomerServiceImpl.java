package org.rebit.crm.service.impl;

import org.rebit.crm.entity.Customer;
import org.rebit.crm.exception.CustomerAlreadyRegisteredException;
import org.rebit.crm.exception.CustomerNotFoundException;
import org.rebit.crm.repository.CustomerRepository;
import org.rebit.crm.service.CustomerService;

public class CustomerServiceImpl implements CustomerService {

	
	private CustomerRepository repo ;
	
	public CustomerServiceImpl(CustomerRepository r) {
		repo = r;
	}

	
	/**
	 * responsible for registering a customer
	 * after successful registration unique id should be assigned
	 * to each customer
	 * @throws CustomerAlreadyRegisteredException
	 * @author Sandeep
	 * @return Customer
	 * @param Customer newCustomer
	 * 
	 */
	@Override
	public Customer register(Customer newCustomer) throws CustomerAlreadyRegisteredException {
		try 
		{
			searchByEmail(newCustomer.getEmail());
			//if there is no exception which means customer already exists
			//then throw CustomerAlreadyRegisteredException
			throw new CustomerAlreadyRegisteredException();
		}
		catch (CustomerNotFoundException e) {
			return repo.save(newCustomer);
		}		
	}

	@Override
	public Customer searchByEmail(String email) throws CustomerNotFoundException {
		
		Customer foundCustomer = repo.findByEmail(email);
		
		if(foundCustomer == null)
		{
			throw new CustomerNotFoundException();
		}
		
		return foundCustomer;
	}

	
}
