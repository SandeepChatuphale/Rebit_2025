package org.rebit.crm.service;

import org.rebit.crm.entity.Customer;
import org.rebit.crm.exception.CustomerAlreadyRegisteredException;
import org.rebit.crm.exception.CustomerNotFoundException;

public interface CustomerService {

	Customer register(Customer newCustomer) throws CustomerAlreadyRegisteredException;
	Customer searchByEmail(String email) throws CustomerNotFoundException;
}
