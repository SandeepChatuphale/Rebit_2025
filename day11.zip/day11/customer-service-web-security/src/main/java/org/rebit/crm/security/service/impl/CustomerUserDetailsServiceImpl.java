package org.rebit.crm.security.service.impl;

import org.rebit.crm.entity.Customer;
import org.rebit.crm.exception.CustomerNotFoundException;
import org.rebit.crm.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

//responsible for fetching UserDetails from DB
//return User Object to Spring security
@Component
public class CustomerUserDetailsServiceImpl implements UserDetailsService {

	@Autowired
	private CustomerService service;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		System.out.println("====In loadUserByUsername ===" + username);
		
		try 
		{
			Customer c = service.searchByEmail(username);
			User authenticatedUser ;
			authenticatedUser = new User(c.getEmail(), 
								c.getPassword(), 
							AuthorityUtils.createAuthorityList(c.getRoles()));
			return authenticatedUser;

		} catch (CustomerNotFoundException e) {
			e.printStackTrace();
			throw new UsernameNotFoundException(username);
		}
		
	}

}
