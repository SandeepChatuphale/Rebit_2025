package org.rebit.crm.exception;

public class CustomerAlreadyRegisteredException extends Exception {

	public CustomerAlreadyRegisteredException(String msg) {
		super(msg);
	}

}
