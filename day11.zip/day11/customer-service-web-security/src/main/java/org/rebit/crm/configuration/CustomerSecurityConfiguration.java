package org.rebit.crm.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.intercept.AuthorizationFilter;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

@EnableWebSecurity()
@Configuration()
public class CustomerSecurityConfiguration {

	@Autowired
	private UserDetailsService service;
	
	DaoAuthenticationProvider dao;
	
	ProviderManager pm;

	@Bean()
	SecurityFilterChain getFilterChain(HttpSecurity http) throws Exception {
		return http

				.cors(c -> c.disable()).csrf(c -> c.disable())
				.authorizeHttpRequests(req -> 
				// endpoint accessible to all
				// .requestMatchers(HttpMethod.POST, "/customer").permitAll()
				// .requestMatchers(HttpMethod.POST, "/customer").anonymous()
//.requestMatchers(HttpMethod.POST, "/customer").hasAnyRole("ADMIN","ANONYMOUS")

						// authenticate any request to any resource
						req.anyRequest().authenticated()
						)
				
				.userDetailsService(service)
				

				// use HttpBasic
				.httpBasic(Customizer.withDefaults()).build();
	}

}
