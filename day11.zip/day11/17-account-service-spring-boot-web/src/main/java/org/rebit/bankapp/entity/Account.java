package org.rebit.bankapp.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tbl_account")
public class Account {
	//instance variables
	//assigned with default values based on data type
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int accountNumber;
	private float balance;
	private String owner;

	//For JPA
	public Account() {
	}
	
	//parameterized constructor
	public Account(float balance, String owner) {
		super();
		this.balance = balance;
		this.owner = owner;
	}
	
	public int getAccountNumber() {
		return accountNumber;
	}
	
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
	
	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	//prints use-ful information about object
	@Override
	public String toString() {
		return "accountNumber=" + accountNumber + ", balance=" 
					+ balance + ", owner=" + owner ;
	}
	
	
	
	
	
	
	
}
