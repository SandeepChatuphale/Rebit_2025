package org.rebit;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HelloController {

	// /hi is URI
	//@GetMapping is mapped with HTTP GET method
	@GetMapping("/hi")
	public String sayHello()
	{
		System.out.println("In sayHello()");
		return "hello";	//this is a name of view page
	}
}
