package org.rebit;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

//REST - 
@RestController
public class HelloRestController {

	@GetMapping("/hello")
	public String printMessgae()
	{
		System.out.println("In printMessage");
		return "Welcome to Spring REST - Web MVC";//data
	}
	
	@GetMapping("/hellowithname")
	//@RequestParam - to fetch query parameters
	public String printName(@RequestParam String name)
	{
		System.out.println("In printMessage");
		return "Welcome to Spring REST - Web MVC " + name;//data
	}
	
	//http://localhost:8080/welcome/10
	@GetMapping("/welcome/{id}")
	public String printPathParam(@PathVariable int id)
	{
		System.out.println("Id is " + id);
		return "Fetch record with id " + id;
	}
	
	
	
	
}
