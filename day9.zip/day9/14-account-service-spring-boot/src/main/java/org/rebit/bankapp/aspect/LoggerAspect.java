package org.rebit.bankapp.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class LoggerAspect {

	
	//@Before("execution(public void deleteByAccountnumber(int))")
	@After("within(org.rebit.bankapp.service.impl.*))")
	public void logAdvice(JoinPoint jp) {  
		System.out.println("In logAdvice() " + jp.getSignature());
	}
}
