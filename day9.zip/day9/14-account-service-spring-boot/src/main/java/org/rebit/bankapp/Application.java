package org.rebit.bankapp;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication //= @Configuration + @ComponentScan + @EnableAutoConfiguration
public class Application {

	public static void main(String[] args) {
		BeanFactory factory ;
		
		//run method creates and returns spring container object
		factory =  SpringApplication.run(Application.class, args);
	
	}

}
