package org.rebit.bankapp.rest.controller;

import java.util.List;

import org.rebit.bankapp.entity.Account;
import org.rebit.bankapp.exception.AccountNotFoundException;
import org.rebit.bankapp.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AccountRestController {

	@Autowired
	private AccountService service;
	
	@GetMapping("/account/{accountNumber}")
	public Account searchAccountByNumber(@PathVariable int accountNumber)
			throws AccountNotFoundException
	{
		Account foundAccount = service.searchByAccountNumber(accountNumber);
		return foundAccount;
	}
	@GetMapping("/account")
	public List<Account> searchAllAccounts()
	{
		return service.searchAll();
	}
	@DeleteMapping("/account/{accountNumber}")
	public void deleteAccountByAccountNumber(@PathVariable int accountNumber) {
		service.deleteByAccountnumber(accountNumber);
	}
	
	@PostMapping("/account")
	//@RequestBody - to accept request payload
	public Account createNewAccount(@RequestBody Account a)
	{
		Account registeredAccount = service.register(a);
		return registeredAccount;
	}
	
	
	
	
	
	
	
	
}
