package org.rebit.crm.exception;

public class CustomerNotFoundException extends Exception {

}
