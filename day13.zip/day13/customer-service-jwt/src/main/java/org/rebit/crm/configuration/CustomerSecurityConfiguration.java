package org.rebit.crm.configuration;

import org.rebit.crm.jwt.filter.JwtFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.SecurityFilterChain;

@Configuration()
@EnableMethodSecurity
public class CustomerSecurityConfiguration {

	
	@Autowired
	private UserDetailsService service;
	

	@Bean()
	SecurityFilterChain getFilterChain(HttpSecurity http,
									   AuthenticationManager m) throws Exception {
		return http

				.cors(c -> c.disable())
				.csrf(c -> c.disable())
				.authorizeHttpRequests(req -> 
				req
				// endpoint accessible to all
				// .requestMatchers(HttpMethod.POST, "/customer").permitAll()
				// .requestMatchers(HttpMethod.POST, "/customer").anonymous()
				//.requestMatchers(HttpMethod.POST, "/customer").hasAnyRole("ADMIN","ANONYMOUS")
	.requestMatchers(HttpMethod.POST, "/customer/authentication").permitAll()
						// authenticate any request to any resource
						.anyRequest().authenticated()
						)
				
				.userDetailsService(service)
				.addFilter(new JwtFilter(m))

				// use HttpBasic
				.httpBasic(Customizer.withDefaults()).build();
	}
	

	@Bean
	AuthenticationManager authenticationManager(AuthenticationConfiguration c) 
			throws Exception
	{
		return c.getAuthenticationManager();
	}
	
	
	
	
	
}
