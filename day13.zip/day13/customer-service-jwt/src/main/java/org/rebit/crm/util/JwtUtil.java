package org.rebit.crm.util;

import java.util.Base64;
import java.util.Collection;
import java.util.Date;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;

@Component
public class JwtUtil {
	
	public static final String USER_CLAIM = "USER_NAME";
	public static final String ROLES_CLAIM = "ROLES";
	
	//MUST as complex as possible
	//and kept securely
	private String secret = "SECRET_KEY";

	public String createToken(String email, Collection<? extends GrantedAuthority> authorities)
	{		
		String []roles = new String[authorities.size()];

		int i = 0;
		for (GrantedAuthority a : authorities) {
			roles[i] = a.getAuthority();
			i++;
		}
		String token = JWT.create()
				  .withClaim(USER_CLAIM, email)
				  .withArrayClaim(ROLES_CLAIM, roles)
				  .withExpiresAt(new Date(System.currentTimeMillis() + 30000))
				  .sign(Algorithm.HMAC256(secret));
		
		return token;
	}
	
	public String validateToken(String token)
	{
		String encodedPayload = JWT.require(Algorithm.HMAC256(secret))
			.build()
			.verify(token)
			.getPayload();
		
		String payload = new String(Base64.getDecoder().decode(encodedPayload));
		
		return payload;
	}
	
	
	
	
	
}
