package org.rebit.email.repository;

import org.rebit.email.entity.Email;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmailRepository extends JpaRepository<Email, Integer>{
}
