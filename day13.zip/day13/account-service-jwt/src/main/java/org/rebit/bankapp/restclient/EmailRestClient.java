package org.rebit.bankapp.restclient;

import org.rebit.bankapp.request.EmailRequest;

public interface EmailRestClient {

	boolean sendEmail(EmailRequest req);
}
