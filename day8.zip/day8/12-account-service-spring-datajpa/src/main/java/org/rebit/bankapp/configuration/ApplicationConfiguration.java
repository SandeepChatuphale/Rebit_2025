package org.rebit.bankapp.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement	//instructs spring to manage transactions
//scanning for stereo type annotations in given 
//package and its subpackages
@ComponentScan("org.rebit.bankapp")
@EnableJpaRepositories("org.rebit.bankapp.repository")

//read properties file and load all properties in memory
@PropertySource("classpath:application.properties")
public class ApplicationConfiguration {

	//in this class we should define methods returning
	//objects of built-in classes
	//annotate these methods with @Bean
	//so that those objects are registered as spring bean
	@Bean("entityManagerFactory")
	LocalEntityManagerFactoryBean getFactoryBean()
	{
		LocalEntityManagerFactoryBean factoryBean = new LocalEntityManagerFactoryBean();
		factoryBean.setPersistenceUnitName("bankapp");
		return factoryBean;
	}
	
	@Bean("transactionManager")
	PlatformTransactionManager getTransactionManager(LocalEntityManagerFactoryBean f)
	{
		
		
		JpaTransactionManager transactionManager = new JpaTransactionManager(f.getObject());
		return transactionManager;
	}
	
	
	
	
	
}
