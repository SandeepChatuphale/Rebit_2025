package org.rebit.bankapp.repository.impl;

import java.util.List;
import java.util.Optional;

import org.rebit.bankapp.entity.Account;
import org.rebit.bankapp.repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;

@Repository
public class AccountJpaRepositoryImpl implements AccountRepository {

	@Value("${account.findAll.jpql}")
	private String findAllJpql;
	
	@PersistenceContext
	private EntityManager em;
	
	@Transactional
	public Account save(Account a)
	{
		em.persist(a);
		return a;
	}
	public Optional<Account> findById(int accountNumber) {		
		Account foundAccount = em.find(Account.class, accountNumber);
		return Optional.of(foundAccount);
	}
	@Override
	public void deleteById(int accountNumber) {	
		em.remove(em.find(Account.class, accountNumber));
	}
	@Override
	public List<Account> findAll() {
		//Find All
		TypedQuery<Account> query = em.createQuery(findAllJpql, Account.class);
		List<Account> accounts = query.getResultList();
		return accounts;
	}
}







