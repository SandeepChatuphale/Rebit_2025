import java.util.Optional;

public class Demo {

	public static void main(String[] args) {
		
		//Optional
		//introduced in jdk 1.8 
		//to avoid null related issues - used to avoid null check
		//It acts as container of object
			
		//adding value data to Optional container 
		Optional<String> p = Optional.of("data");//to add data to optional
		
		boolean b = p.isPresent();//to check if any value present
		if(b)
		{
			System.out.println(p);
			String s = p.get();//to get data
			System.out.println(s);
		}
		
		
		
		
	}
}
