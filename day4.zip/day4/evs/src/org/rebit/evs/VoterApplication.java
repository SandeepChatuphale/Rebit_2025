package org.rebit.evs;

import org.rebit.evs.factory.BeanFactory;
import org.rebit.evs.service.VoterService;

public class VoterApplication {

	public static void main(String[] args) {
		BeanFactory factory = new BeanFactory();
		VoterService service = factory.getService();
		
		int option = 1;
		
		switch (option) {
		case 1: {
			long count = service.countTotalVoters();
			System.out.println("Total voters registred are " + count);
		}
		}
	}

}
