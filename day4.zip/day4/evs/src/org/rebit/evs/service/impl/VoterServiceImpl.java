package org.rebit.evs.service.impl;

import org.rebit.evs.repository.VoterRepository;
import org.rebit.evs.service.VoterService;

public class VoterServiceImpl implements VoterService{

	private VoterRepository repo;
	
	//Defining constructor
	public VoterServiceImpl(VoterRepository r) {
		repo = r;
	}
		
	@Override
	public long countTotalVoters() {
		return repo.findAll().stream().count();
	}

	@Override
	public double calculateAverageAgeOfVoters() {
		return repo.findAll().stream()
							.mapToDouble(v -> v.getAge())
							.average()
							.getAsDouble();
	}

}
