package org.rebit.evs.service;

public interface VoterService {

	long countTotalVoters();
	double calculateAverageAgeOfVoters();
}
