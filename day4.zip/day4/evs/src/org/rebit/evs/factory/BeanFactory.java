package org.rebit.evs.factory;

import org.rebit.evs.repository.VoterRepository;
import org.rebit.evs.repository.impl.VoterRepositoryImpl;
import org.rebit.evs.service.VoterService;
import org.rebit.evs.service.impl.VoterServiceImpl;

public class BeanFactory {

	private VoterRepository repo;
	private VoterService service;
	
	public BeanFactory() {
		repo = new VoterRepositoryImpl();
		service = new VoterServiceImpl(repo);
	}
	
	public VoterService getService() {
		return service;
	}
}
