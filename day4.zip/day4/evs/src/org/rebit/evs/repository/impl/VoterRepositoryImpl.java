package org.rebit.evs.repository.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.rebit.evs.entity.Voter;
import org.rebit.evs.repository.VoterRepository;

public class VoterRepositoryImpl implements VoterRepository {

	private List<Voter> voters ;
	
	public VoterRepositoryImpl() {
		voters = new ArrayList<>();
		Voter v1 = new Voter(1, "me", 34, "Male");//dummy data
		voters.add(v1);
	}
	
	@Override
	public List<Voter> findAll() {
		return voters;
	}
	
	@Override
	public Optional<Voter> findById(int id)
	{
		Optional<Voter> o = voters.stream()
			  .filter(v -> v.getId() == id)
			  .findFirst();
		
		
		return o;
	}
}
