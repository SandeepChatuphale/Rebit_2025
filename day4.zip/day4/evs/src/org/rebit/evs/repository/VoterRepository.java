package org.rebit.evs.repository;

import java.util.List;
import java.util.Optional;

import org.rebit.evs.entity.Voter;

public interface VoterRepository {

	List<Voter> findAll();

	Optional<Voter> findById(int id);
}
