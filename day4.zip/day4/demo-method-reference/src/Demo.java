import java.util.function.Consumer;

public class Demo {

	public static void main(String[] args) {
		
		Demo o = new Demo();
		//Consumer<String> c = str -> System.out.println(str);
		
		//method reference
		//short hand way of writing lambda
		//if method signature matches lamdba expression
		//Consumer<String> c = o :: display;
		Consumer<String> c = System.out :: println;
		
		c.accept("Invoking");
	}
	
	//it is already present
	void display(String data) {
		System.out.println(data);
	}

}
