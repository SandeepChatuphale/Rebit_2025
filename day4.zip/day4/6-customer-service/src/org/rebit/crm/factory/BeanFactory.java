package org.rebit.crm.factory;

import org.rebit.crm.repository.CustomerRepository;
import org.rebit.crm.repository.impl.CustomerRepositoryImpl;
import org.rebit.crm.service.CustomerService;
import org.rebit.crm.service.impl.CustomerServiceImpl;

public class BeanFactory {
	private CustomerRepository repo;
	private CustomerService service;
	
	//constructor
	public BeanFactory() {
		repo = new CustomerRepositoryImpl();
		service = new CustomerServiceImpl(repo);
	}
	public CustomerRepository getCustomerRepository(){
		return repo;
	}
	public CustomerService getCustomerService() {
		return service;
	}
	
	
	
	
}
