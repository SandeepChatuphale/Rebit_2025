package org.rebit.crm.repository.impl;

import org.rebit.crm.entity.Customer;
import org.rebit.crm.repository.CustomerRepository;

public class CustomerRepositoryImpl implements CustomerRepository {

	@Override
	public Customer save(Customer newCustomer) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer findByEmail(String email) {
		Customer foundCustomer = new Customer("abc@gmail.com", "abc");
		return foundCustomer;
	}

}
