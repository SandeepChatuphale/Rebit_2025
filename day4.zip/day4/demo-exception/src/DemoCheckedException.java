import java.io.IOException;

public class DemoCheckedException {

	public static void main(String[] args) {
		DemoCheckedException d = new DemoCheckedException();
		try {
			d.display();
		} catch (IOException e) {
			e.printStackTrace();
		}	
	}
	void display()throws IOException
	{
		IOException e = new IOException();
		throw e;
	}

}
