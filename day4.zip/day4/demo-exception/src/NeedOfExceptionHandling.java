
public class NeedOfExceptionHandling {

	public static void main(String[] args) {

		int a = 10;
		int b = 0;
		try {
			System.out.println(a/b);
			System.out.println("got result");
		}
		catch (ArithmeticException e) {
			System.out.println("Cannot divide by zero");
		}
		finally {
			
		}
		System.out.println("Thank you");
		
		//try	- doubtful statements
				//statements which might generate Exception
		//catch - used to handle exception
		//finally - always executed irrespective of whether exception is there 
					//OR not
					//used to close resources
		//throw - to programmatically throw Exception
				//useful in case of UserDefined Exception
		//throws - to specify a method might throw Exception
		
		
		//types of Exception
			//1 checked
				//e.g. SQLException,IOException
				//for checked exception we MUST follow a rule 
				//known as "handle OR declare"
				//handle - means try-catch
				//declare - means - throws clause
		
			//2 unchecked
			//e.g.ArithmeticException,NullPointerException
		
		
		
		
		
	}

}
