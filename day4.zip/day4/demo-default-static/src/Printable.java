
public interface Printable {

	//prior to jdk 8 interface can ONLY contain abstract method
	
	//from jdk 8 and above interface can contain 
	//default and static methods
	default void print()
	{
		System.out.println("in default method");
	}
	
	static void printType()
	{
		System.out.println("In static method of interface");
	}
}
