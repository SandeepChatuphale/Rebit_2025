package org.rebit.bankapp.repository.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.rebit.bankapp.entity.Account;
import org.rebit.bankapp.repository.AccountRepository;

//responsible for talking to data-store (DB)
//provides CRUD operation for Account entity
public class AccountRepositoryImpl implements AccountRepository{
	
	private List<Account> accounts;
	
	public AccountRepositoryImpl() {
		
		//Hard-coded data
		Account a1 = new Account(1, 5000, "Me");
		Account a2 = new Account(2, 4000, "We");
		Account a3 = new Account(3, 6000, "You");
		
		accounts = new ArrayList<>();
		accounts.add(a1);
		accounts.add(a2);
		accounts.add(a3);		
	}
	
	//C - save
	public Account save(Account a)
	{
		System.out.println("Saving Account in DB ");
		return a;
	}
	
	//R - READ
	public Optional<Account> findById(int accountNumber) {
		
		Account a = new Account(1, 5000, "Me");
		return Optional.of(a);
		//return null;
	}

	@Override
	public void deleteById(int id) {
	}

	@Override
	public List<Account> findAll() {
		return accounts;
	}
	
	
	
	
}
