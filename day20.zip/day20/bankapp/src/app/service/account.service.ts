import { Injectable } from '@angular/core';
import { Account } from '../dto/Account';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AccountService {

  accounts :Account[] = []

  constructor(private http:HttpClient) { }

  save(a:Account)
  {
    this.accounts.push(a)
  }

  findAll() : Observable<Account[]>{
    
    //fetch token from sessionStorage
    /*
    const token = sessionStorage.getItem('JWT_KEY')

    let headers = new HttpHeaders()
                      .append('Authorization','Bearer ' + token)

    return this.http.get<Account[]>('http://localhost/acs/account',{headers})
    */
    return this.http.get<Account[]>('http://localhost/acs/account')


  }


  deleteAccountById(accN:number){

    //fetch token from sessionStorage
    /* this is done request interceptot
    const token = sessionStorage.getItem('JWT_KEY')

    let headers = new HttpHeaders()
                      .append('Authorization','Bearer ' + token)
                      

    return this.http.delete<void>('http://localhost/acs/account/'+accN,{headers})
    */
    return this.http.delete<void>('http://localhost/acs/account/'+accN)
  }
  


}