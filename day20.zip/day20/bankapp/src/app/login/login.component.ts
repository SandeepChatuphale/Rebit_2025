import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CustomerService } from '../service/customer.service';
import { Customer } from '../dto/Customer';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule,CommonModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  email:string =''
  password : string = ''
  message = ''
  status = false;

  constructor(private service: CustomerService){}

  performLogin()
  {
    let c = new Customer(this.email,this.password)

    //ONLY WHEN we subscribe() REST call is made
    this.service.login(c).subscribe({
      //next code is executed ONLY WHEN API returns SUCCESS
      next : success => {
        this.message = 'login success'
        this.status = true
        //console.log(success)//ONLY for debugging

        //save token securely for logged in of user
        this.service.saveToken(success.jwttoken);
      },

      //error code is executed ONLY WHEN API returns ERROR
      error : e => {
         this.message = 'bad credentials'
         this.status = false
      }
    })

    /*
    if(this.service.login(c))
    {
      this.message = 'login success'
      this.status = true
    }
    else{
      this.message = 'bad credentials'
    }
      */
  }
}
