import { Component } from '@angular/core';
import { CustomerService } from '../service/customer.service';

@Component({
  selector: 'app-logout',
  standalone: true,
  imports: [],
  templateUrl: './logout.component.html',
  styleUrl: './logout.component.css'
})
export class LogoutComponent {

  constructor(private service : CustomerService){}

  confirmLogout()
  {
    const res = confirm('are you sure?')

    if(res)
    {
      this.service.deleteToken()
    }

  }
}
