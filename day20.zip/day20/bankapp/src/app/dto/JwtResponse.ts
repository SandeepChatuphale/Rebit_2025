export class JwtResponse{

    //this field name is matched with 
    //api response from server
    constructor(public jwttoken:string){}
}