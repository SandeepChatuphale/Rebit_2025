export class Account{
    constructor(public accountNumber:number,
        public balance:number,
        public owner:string
    ){}
}