import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Account } from '../dto/Account';
import { AccountService } from '../service/account.service';


@Component({
  selector: 'app-account',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './account.component.html',
  styleUrl: './account.component.css'
})
export class AccountComponent {

  a = new Account(0,0,'')

  constructor(private service : AccountService){}

  createNewAccount()
  {
    let ac = new Account(0,this.a.balance,this.a.owner)
    //save it to repo 
    this.service.save(ac)
  }
}
