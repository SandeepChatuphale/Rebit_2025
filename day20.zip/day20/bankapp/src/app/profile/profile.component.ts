import { Component } from '@angular/core';
import { CustomerService } from '../service/customer.service';
import { Customer } from '../dto/Customer';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css'
})
export class ProfileComponent {

  authenticated = new Customer('','')

  constructor(private service : CustomerService){
    this.showProfile()
  }

  showProfile()
  {
    this.authenticated = this.service.findProfileDetails()
  }

}
