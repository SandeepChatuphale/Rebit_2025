class Customer{
    constructor(email,password){
        this.email = email;
        this.password = password;
    }
}

let email;
let password;

function validateEmail()
{
    let email = document.getElementById('e').value;
    
    if(email == '')
    {
        document.getElementById('emailerror').innerHTML ='Email is MUST'
        document.getElementById('b').setAttribute('disabled','disabled')
    }
    else{
        document.getElementById('emailerror').innerHTML =''
        document.getElementById('b').removeAttribute('disabled')
    }
}

function validatePassword()
{
    
}

function performLogin()
{
    console.log('====in performLogin===')

    //1 fetch values from user
    let email = document.getElementById('e').value

    let pass = document.getElementById('p').value

    //2 send those to server
    let c = new Customer(email,pass);
    console.log(c)
    let xhr = new XMLHttpRequest();
    xhr.open('POST','http://localhost/cs/customer/authentication',true)
    xhr.setRequestHeader('Content-Type','application/json')
    let str = JSON.stringify(c);
    console.log(str)

    xhr.onload = function()
    {
        let resp = xhr.responseText;
        console.log(resp)
        let token = JSON.parse(resp);
        console.log(token.jwttoken)

        xhr.open('GET','http://localhost/acs/account',true)
        xhr.setRequestHeader('Authorization','Bearer ' + token.jwttoken)
        xhr.onload = function()
        {
            console.log(xhr.responseText)
            let data = JSON.parse(xhr.responseText)
            showAccounts(data)
        }
        xhr.send()
    }
    xhr.send(str)
}
function showAccounts(data)
{
    console.log('============================')
    console.log(data)

    //modify DOM dynamically
    document.write(data[0].owner)
}
