let id = 10;   //data type is decided by type of value assigned 


let age : number = 10;
//age = 'me' ERROR

let owner : string = 'ajay'

let flag : boolean = true