function sayHello()
{
    console.log('in sayHello()')
}

function printHello() : void
{

}

function add(a:number,b:number) : number{
    return a + b;
}