"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Account = void 0;
var Account = /** @class */ (function () {
    //instance 
    /*    private accountNumber : number;
        public balance : number;
        protected owner : string
    
    
        constructor(a : number = 0,balace:number=0,owner:string=''){
            this.accountNumber = a;
            this.balance = balace;
            this.owner = owner
        }
            */
    function Account(accountNumber, balance, owner) {
        if (accountNumber === void 0) { accountNumber = 0; }
        if (balance === void 0) { balance = 0; }
        if (owner === void 0) { owner = ''; }
        this.accountNumber = accountNumber;
        this.balance = balance;
        this.owner = owner;
        this.count = 1;
    }
    return Account;
}());
exports.Account = Account;
