var id = 10; //data type is decided by type of value assigned 
var age = 10;
//age = 'me' ERROR
var owner = 'ajay';
var flag = true;
