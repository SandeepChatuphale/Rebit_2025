interface OnInit{
}

export class Account implements OnInit{

    readonly count:number = 1;

     //instance 

/*    private accountNumber : number;
    public balance : number;
    protected owner : string


    constructor(a : number = 0,balace:number=0,owner:string=''){
        this.accountNumber = a;
        this.balance = balace;
        this.owner = owner
    }
        */
constructor(public accountNumber:number=0,public balance:number = 0,public owner:string=''){}  
}


//sub-class
class SavingsAccount extends Account{}


//Decorator in ts 