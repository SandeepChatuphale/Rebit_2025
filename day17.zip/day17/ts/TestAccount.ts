import { Account } from "./3-class";


let a = new Account();
console.log(a.accountNumber)
console.log(a.balance)
console.log(a.owner)

let a1 : Account = new Account(1,5000,'me');
console.log(a1.accountNumber)
console.log(a1.balance)
console.log(a1.owner)

let accounts : Account[] = [];
accounts.push(a1)
accounts.push(a);

console.log(accounts)

accounts = accounts.filter(a => a.balance>2000)
console.log(accounts)