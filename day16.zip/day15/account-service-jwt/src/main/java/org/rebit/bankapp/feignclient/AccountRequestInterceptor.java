package org.rebit.bankapp.feignclient;

import org.rebit.bankapp.util.JwtUtil;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import feign.RequestInterceptor;
import feign.RequestTemplate;

@Component
public class AccountRequestInterceptor implements RequestInterceptor{

	//this method automatically executed when REST call is made using open-feign
	@Override
	public void apply(RequestTemplate template) {
		
		System.out.println("====IN apply of RequestInterceptor=====");
		//write logic of passing Bearer Header to email-service
		String token = JwtUtil.jwtToken;
		System.out.println(token);
		
		template.header(HttpHeaders.AUTHORIZATION, "Bearer " + token);
	}

}
