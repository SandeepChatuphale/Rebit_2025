package org.rebit.bankapp.configuration;

import org.rebit.bankapp.jwt.filter.JwtFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.context.support.WebApplicationContextUtils;

import jakarta.servlet.ServletContext;

@Configuration
public class EmailSecurityConfiguration {
	
	@Autowired
	private ServletContext context;
	
	@Bean
	SecurityFilterChain getFilterChain(HttpSecurity http,AuthenticationManager m) throws Exception
	{
		return http
			.authorizeHttpRequests(req -> req.anyRequest().authenticated())
			.addFilter(new JwtFilter(m,WebApplicationContextUtils.getWebApplicationContext(context)))
			.csrf(c -> c.disable())
			.cors(c -> c.disable())
			.build();
	}
	@Bean
	AuthenticationManager authenticationManager(AuthenticationConfiguration c) throws Exception
	{
		return c.getAuthenticationManager();
	}
}
