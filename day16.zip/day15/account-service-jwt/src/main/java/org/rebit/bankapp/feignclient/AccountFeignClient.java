package org.rebit.bankapp.feignclient;

import org.rebit.bankapp.request.EmailRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "es")
public interface AccountFeignClient {

	@PostMapping("/email")
	public EmailRequest sendEmail(@RequestBody EmailRequest e);
}
