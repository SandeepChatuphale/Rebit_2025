package org.rebit.bankapp.util;

import java.util.Base64;
import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;

@Component
public class JwtUtil {
	
	public static final String USER_CLAIM = "USER_NAME";
	public static final String ROLES_CLAIM = "ROLES";
	
	//MUST as complex as possible
	//and kept securely
	@Value("${jwt.secret.key}")
	private String secret = "SECRET_KEY";
		
	public static String jwtToken;

	public String validateToken(String token)
	{
		
		String encodedPayload = JWT.require(Algorithm.HMAC256(secret))
			.build()
			.verify(token)
			.getPayload();
		
		jwtToken = token;
		
		String payload = new String(Base64.getDecoder().decode(encodedPayload));
		
		return payload;
	}

		
		
	
	
	
	
	
}
