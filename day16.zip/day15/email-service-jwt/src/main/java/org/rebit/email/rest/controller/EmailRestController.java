package org.rebit.email.rest.controller;

import org.rebit.email.entity.Email;
import org.rebit.email.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/email")
public class EmailRestController {
	

	@Autowired
	private EmailService service;
	
	@Value("${organization}")
	private String company;
	
	@Autowired
	private Environment env;
	
	private String port;
	
	@GetMapping
	public String getMessage() {
		
		port = env.getProperty("local.server.port");
		System.out.println("=======port =====================" + port);
		return company +" =====>   " + port;
	}
	
	
	
	@PostMapping
	public ResponseEntity<Email> create(@RequestBody Email e)
	{
		e = service.sendEmail(e);
		
		ResponseEntity<Email> res = 
				new ResponseEntity<Email>(e, HttpStatus.CREATED);
	
		return res;
	}
	
	
	
	
}
