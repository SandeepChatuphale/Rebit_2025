package org.rebit.email.configuration;

import org.rebit.email.jwt.filter.JwtFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class EmailSecurityConfiguration {
	
	@Bean
	SecurityFilterChain getFilterChain(HttpSecurity http,AuthenticationManager m) throws Exception
	{
		return http
				.csrf(c -> c.disable())
				.cors(c -> c.disable())
				
			.authorizeHttpRequests(req -> 
			req
			.requestMatchers(HttpMethod.GET,"/email").permitAll()
			.requestMatchers("/actuator/**").permitAll()
			
			.anyRequest().authenticated())
			.addFilter(new JwtFilter(m))
			.build();
	}
	@Bean
	AuthenticationManager authenticationManager(AuthenticationConfiguration c) throws Exception
	{
		return c.getAuthenticationManager();
	}
}
