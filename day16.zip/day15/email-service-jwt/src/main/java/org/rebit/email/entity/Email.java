package org.rebit.email.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tbl_email")
public class Email {

	@Id
	@GeneratedValue
	private int id;
	private String receiver;
	private String subjectMsg;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getReceiver() {
		return receiver;
	}
	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}
	public String getSubjectMsg() {
		return subjectMsg;
	}
	public void setSubjectMsg(String subjectMsg) {
		this.subjectMsg = subjectMsg;
	}
}
