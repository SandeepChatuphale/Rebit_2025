package org.rebit.crm.error.representation;

public record CustomerErrorRecord(String message,int code) {
}
