package org.rebit.crm.rest.controller;

import org.rebit.crm.entity.Customer;
import org.rebit.crm.error.representation.CustomerErrorRecord;
import org.rebit.crm.exception.CustomerAlreadyRegisteredException;
import org.rebit.crm.exception.CustomerNotFoundException;
import org.rebit.crm.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/customer")
public class CustomerRestController {

	@Autowired
	private CustomerService service;
	
	
	@PostMapping
	public ResponseEntity<?> register(@Valid @RequestBody Customer c ) throws CustomerAlreadyRegisteredException
	{
			Customer registeredCustomer = service.register(c);
			ResponseEntity<Customer> res = new ResponseEntity<Customer>(registeredCustomer, HttpStatus.CREATED);
			return res;
		
	}

	@ExceptionHandler(CustomerAlreadyRegisteredException.class)
	public ResponseEntity<CustomerErrorRecord> 
		handleCustomerAlreadyRegisteredException(CustomerAlreadyRegisteredException e)
	{
		CustomerErrorRecord r = new CustomerErrorRecord(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR.value());
				
		ResponseEntity<CustomerErrorRecord> res = 
				new ResponseEntity<CustomerErrorRecord>(r, 
				HttpStatus.INTERNAL_SERVER_ERROR);

		return res;
	}
	
	@GetMapping()
	public ResponseEntity<?> searchByEmail(@RequestParam String email)
	{
		try {
			Customer foundCustomer = service.searchByEmail(email);
			ResponseEntity<Customer> res = new ResponseEntity<Customer>(foundCustomer, 
					HttpStatus.OK);
			return res;
		} catch (CustomerNotFoundException e) {
			e.printStackTrace();
			ResponseEntity<String> res = new ResponseEntity<String>("Not found",
					HttpStatus.NOT_FOUND);
			return res;
					
		}
	}
	
	
	
	
}