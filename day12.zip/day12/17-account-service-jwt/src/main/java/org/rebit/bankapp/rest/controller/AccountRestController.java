package org.rebit.bankapp.rest.controller;

import java.util.List;

import org.rebit.bankapp.entity.Account;
import org.rebit.bankapp.error.representation.AccountNotFoundErrorRepresentation;
import org.rebit.bankapp.exception.AccountNotFoundException;
import org.rebit.bankapp.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/account") // common portion of URI
public class AccountRestController {

	@Autowired
	private AccountService service;

	@PostMapping()
	// @RequestBody - to accept request payload
	public ResponseEntity<Account> createNewAccount(@RequestBody Account a) {
		Account registeredAccount = service.register(a);
		ResponseEntity<Account> res = new ResponseEntity<Account>(registeredAccount, HttpStatus.CREATED);
		return res;
	}

	@GetMapping("/{accountNumber}")
	public ResponseEntity<Account> searchAccountByNumber(@PathVariable int accountNumber)
			throws AccountNotFoundException {
		Account foundAccount = service.searchByAccountNumber(accountNumber);
		ResponseEntity<Account> resp = new ResponseEntity<Account>(foundAccount, HttpStatus.OK);
		return resp;
	}

	// spring will execute method if any of the method of this class is going to
	// throw
	// AccountNotFoundException
	@ExceptionHandler(AccountNotFoundException.class)
	public ResponseEntity<AccountNotFoundErrorRepresentation> handleAccountNotFoundException() {
		System.out.println("In handleAccountNotFoundException method ");
		
		AccountNotFoundErrorRepresentation r = 
				new AccountNotFoundErrorRepresentation();
		
		r.setCode(HttpStatus.NOT_FOUND.value());
		r.setMessage("Account Not Found");
		
		ResponseEntity<AccountNotFoundErrorRepresentation> res = 
		new ResponseEntity<AccountNotFoundErrorRepresentation>(r, HttpStatus.NOT_FOUND);
		
		return res;
	}

	@GetMapping()
	public ResponseEntity<List<Account>> searchAllAccounts() {
		List<Account> all = service.searchAll();
		ResponseEntity<List<Account>> res = new ResponseEntity<List<Account>>(all, HttpStatus.OK);
		return res;
	}

	@DeleteMapping("/{accountNumber}")
	public ResponseEntity<?> deleteAccountByAccountNumber(@PathVariable int accountNumber)
			throws AccountNotFoundException {
		service.searchByAccountNumber(accountNumber);
		service.deleteByAccountnumber(accountNumber);
		ResponseEntity<Void> res = new ResponseEntity<>(HttpStatus.NO_CONTENT);
		return res;
	}

}
