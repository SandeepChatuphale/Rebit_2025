package org.rebit.bankapp.jwt.filter;

import java.io.IOException;

import org.rebit.email.web.response.UserResponse;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.web.client.RestClient;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

//this class is responsible for accepting jwt token
//from Authorization header
//doFilterInternal() method is executed once per request to a secured endpoint
public class JwtFilter extends BasicAuthenticationFilter {

	
	public JwtFilter(AuthenticationManager authenticationManager) {
		super(authenticationManager);
		
	}
	
	@Override
	protected void doFilterInternal(HttpServletRequest request, 
			HttpServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		System.out.println("In doFilterInternal of JwtFilter");
		
		String header = request.getHeader(HttpHeaders.AUTHORIZATION);
		
		if(header != null && header.startsWith("Bearer"))
		{
			System.out.println("header ====> " + header);
			
//			JwtUtil util = new JwtUtil();
//			
//			//removing Bearer 
//			String token = header.substring(7);
//			
//			token = util.validateToken(token);
//			
//			//once token is validated get the claims from token
//			//and validate user
//		
//			JsonParser parser = JsonParserFactory.getJsonParser();
//			Map<String, Object> m = parser.parseMap(token);
//			
//			String email = (String) m.get(JwtUtil.USER_CLAIM);
//			List<String> roles = (List<String>) m.get(JwtUtil.ROLES_CLAIM);
//			
//			Authentication auth;
//			
//			auth = new UsernamePasswordAuthenticationToken(email,
//					null,
//					AuthorityUtils.createAuthorityList(roles));

			ResponseEntity<UserResponse> entity = RestClient.create("http://localhost:8080/customer/token/validation").get()
			.header(HttpHeaders.AUTHORIZATION, header)
			.retrieve()
			.toEntity(UserResponse.class);
			System.out.println();
			
			if(entity.getStatusCode() == HttpStatus.OK)
			{
				System.out.println();
				UserResponse res = entity.getBody();
				
				Authentication auth = new UsernamePasswordAuthenticationToken(res.getEmail(), null,AuthorityUtils.createAuthorityList(res.getRoles()));
				
				SecurityContext context = SecurityContextHolder.getContext();
				context.setAuthentication(auth);
			}
		
		}
		//
		chain.doFilter(request, response);
		
		
		
		
		
		
		
	}
}
