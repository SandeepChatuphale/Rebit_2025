package org.rebit.bankapp.service.impl;

import java.util.List;
import java.util.Optional;

import org.rebit.bankapp.entity.Account;
import org.rebit.bankapp.exception.AccountNotFoundException;
import org.rebit.bankapp.repository.AccountRepository;
import org.rebit.bankapp.request.EmailRequest;
import org.rebit.bankapp.restclient.EmailRestClient;
import org.rebit.bankapp.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AccountServiceImpl implements AccountService {

	//coding to interface
	@Autowired
	private AccountRepository repo;
	
	@Autowired
	private EmailRestClient restClient;
	
	@Override
	public Account register(Account a) {
		Account registeredAccount = repo.save(a);
		
		//invoke email endpoint
		EmailRequest req = new EmailRequest(a.getOwner(), "Welcome");
		restClient.sendEmail(req);
		
		return registeredAccount;
	}

	@Override
	public Account searchByAccountNumber(int accountNumber) throws AccountNotFoundException {
		System.out.println("In----");
		Optional<Account> o = repo.findById(accountNumber);
	
		//if account NOT found 
		if(o.isEmpty())
		{
			//throw Customexception
			AccountNotFoundException ex = new AccountNotFoundException();
			throw ex;
		}
		return o.get();
	}

	@Override
	public void deleteByAccountnumber(int accountNumber) {
		// TODO Auto-generated method stub
		System.out.println("in deleteByAccountnumber");
		repo.deleteById(accountNumber);
		
	}

	@Override
	public List<Account> searchAll() {
		return repo.findAll();
	}

	@Override
	public List<Account> searchAllEligibleForCreditCard(int amount) {
		return this.repo.findAll().stream()
						   .filter(acc -> acc.getBalance() > amount)
						   .toList();
	}

	@Override
	public List<String> searchAllOwnersMaintainingBalance(int amount) {
		return repo.findAll()
				   .stream()
				   .filter(acc -> acc.getBalance() > amount)
				   .map(acc -> acc.getOwner())
				   .toList();
	}

	//bank is interesetd is knowing total balance of all accounts
	//for lending loan purpose
	@Override
	public double calculateTotalBalance() {
		return repo.findAll()
				   .stream()
				   .mapToDouble(acc -> acc.getBalance())
				   .sum();
	}
}
