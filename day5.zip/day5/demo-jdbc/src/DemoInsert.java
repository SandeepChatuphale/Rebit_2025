import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DemoInsert {

	public static void main(String[] args) {

		try {
			Class.forName("com.mysql.jdbc.Driver");//step 1
			
			//jdbcurl
			//syntax : - protocol:subprotocol:subname
			//jdbc:mysql://localhost:3306/
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bankapp_db",
														 "root",
														 "root");
			
			
			//? place holder
			PreparedStatement pstmt = 
					con.prepareStatement("INSERT INTO tbl_account VALUES(?,?,?)");
			
			//setting values to ? place holder
			//MUST before firing the query
			pstmt.setInt(1, 20);
			pstmt.setDouble(2, 7000);
			pstmt.setString(3,"Ajay");
			
			
			
			int numberOfRowsUpdated = pstmt.executeUpdate();//firing the query
			
			System.out.println(numberOfRowsUpdated);
			
			pstmt.close();
			con.close();
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

}
