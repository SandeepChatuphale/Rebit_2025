import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DemoSelect {

	public static void main(String[] args) {

		try {
			Class.forName("com.mysql.jdbc.Driver");//step 1
			
			//jdbcurl
			//syntax : - protocol:subprotocol:subname
			//jdbc:mysql://localhost:3306/
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/",
														 "root",
														 "root");
			PreparedStatement pstmt = con.prepareStatement("SELECT * FROM tbl_account");
			
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next())//run loop till end of all records
			{
				System.out.print(rs.getInt(1));//get the value of column 1
				System.out.print(rs.getDouble(2));//get the value of column 2
				System.out.println(rs.getString(3));//get the value of column 3
			}

			
			pstmt.close();
			con.close();
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

}
