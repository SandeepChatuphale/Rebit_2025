package org.rebit.bankapp.repository.impl;

import java.util.List;
import java.util.Optional;

import org.rebit.bankapp.entity.Account;
import org.rebit.bankapp.repository.AccountRepository;

public class AccountJpaRepositoryImpl implements AccountRepository {

	public Account save(Account a)
	{
		System.out.println("Saving in DB using old code");
		return a;
	}
	
	public Optional<Account> findById(int accountNumber) {
		Account a = new Account(1, 5000, "Me");
		return Optional.of(a);
	}

	@Override
	public void deleteById(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Account> findAll() {
		// TODO Auto-generated method stub
		return null;
	}
}
