package org.rebit.bankapp.repository;

import java.util.List;
import java.util.Optional;

import org.rebit.bankapp.entity.Account;

public interface AccountRepository {

	public Account save(Account a);
	public Optional<Account> findById(int accountNumber);
	void deleteById(int id);
	List<Account> findAll();
}
