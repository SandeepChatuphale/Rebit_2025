import { HttpHeaders, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { CustomerService } from '../service/customer.service';

export const requestInterceptor: HttpInterceptorFn = (req, next) => {
  console.log('====inside requestInterceptor=====')
  //if user is loggedIn
  const service = inject(CustomerService)
  
  if(service.isLoggedIn()){
  //get the token
  const token = sessionStorage.getItem(service.JWT_KEY)
  //append Authorization header
  const newRequest = req.clone({
    headers : req.headers.set(service.AUTHORIZATION,service.BEARER + token)
  })
  return next(newRequest);
}
return next(req);
};
