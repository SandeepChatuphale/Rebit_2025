import { CommonModule } from '@angular/common';
import { Component, computed, DoCheck, OnInit } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CustomerService } from '../service/customer.service';

@Component({
  selector: 'app-menu',
  standalone: true,
  imports: [CommonModule,RouterModule],
  templateUrl: './menu.component.html',
  styleUrl: './menu.component.css'
})
export class MenuComponent implements OnInit{

  today = new Date()

  //signal
  email = () => ''

  isLoggedIn = () => false
  //
  constructor(public service : CustomerService){}
  ngOnInit(): void {

    //email value is automatically computed based on value of auth signal
    this.email = computed(()=>this.service.auth())  
    
    this.isLoggedIn = computed(()=>this.service.isLoggedIn())
  }
}
