import { inject } from '@angular/core';
import { ActivatedRoute, CanActivateFn, Router } from '@angular/router';
import { CustomerService } from '../service/customer.service';

export const authGuard: CanActivateFn = (route, state) => {
  console.log('===============in side authguard================')

  const service = inject(CustomerService)
  const r = inject(Router)

  //if we return true from here 
  //route for which this guard is executed is allowed to access
  if(service.isLoggedIn()){
    return true;
  }
  //if we return false from here 
  //route for which this guard is executed is NOT allowed to access
  r.navigate(['login'])
  return false;
};