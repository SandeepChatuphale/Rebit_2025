import { Injectable, signal } from '@angular/core';
import { Customer } from '../dto/Customer';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { JwtResponse } from '../dto/JwtResponse';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  readonly JWT_KEY = 'JWT_KEY'
  readonly AUTHORIZATION = 'Authorization'
  readonly BEARER = 'Bearer '
  readonly BASE_URL = 'http://localhost'

  authenticatedCustomer : Customer = new Customer('','');

  timeout = signal(0)

  //declaring signal with initial value
  auth = signal('')
  

  //loggedInUser = ''
  //loggedUserRoles = []

  customers : Customer[] = []

  //initially user is NOT logged in
  isLoggedIn = signal(false)

  //injecting HttpClient
  constructor(private http : HttpClient) { }

  register(c:Customer)
  {
    this.customers.push(c)
  }

  login(c:Customer) :Observable<JwtResponse>
  {
    return this.http.post<JwtResponse>(this.BASE_URL + '/cs/customer/authentication',c)
    /*
    if(c.email == 'admin' && c.password == 'admin')
      {
        return true
      }
      else
       return false;
      */
  }

  findProfileDetails()
  {
    const token = sessionStorage.getItem(this.JWT_KEY);
    
    if(token)
    {
      const encodedPayload  = token?.split('.')[1]
      console.log(encodedPayload)
      let payload:any = atob(encodedPayload)
      payload = JSON.parse(payload)
      
      let t: number=  parseInt(payload.exp)
    
      this.authenticatedCustomer.email = payload.USER_NAME;
      this.authenticatedCustomer.roles = payload.ROLES;
      this.timeout.set(t-Date.now());

      //changing the value of signal
      this.auth.set(this.authenticatedCustomer.email)
    }

    return this.authenticatedCustomer;
  }

  saveToken(token:string)
  {
    sessionStorage.setItem(this.JWT_KEY,token)
    this.isLoggedIn.set(true)
    this.findProfileDetails()

  }

  deleteToken(){
    sessionStorage.removeItem(this.JWT_KEY)
    sessionStorage.clear()
    this.isLoggedIn.set(false)
  }
}
