import { Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { AccountComponent } from './account/account.component';
import { AccountsComponent } from './accounts/accounts.component';
import { ProfileComponent } from './profile/profile.component';
import { LogoutComponent } from './logout/logout.component';
import { NotfoundComponent } from './notfound/notfound.component';
import { authGuard } from './guard/auth.guard';

export const routes: Routes = [
    {path:'login',component:LoginComponent},
    {path:'profile/:name',component:ProfileComponent,canActivate:[authGuard]},
    {path:'accounts',component:AccountsComponent,canActivate:[authGuard]},
    {path:'account',component:AccountComponent,canActivate:[authGuard]},
    {path:'logout',component:LogoutComponent,canActivate:[authGuard]},
    {path:'**',component:NotfoundComponent}
];
