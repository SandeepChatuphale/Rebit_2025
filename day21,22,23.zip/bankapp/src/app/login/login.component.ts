import { CommonModule } from '@angular/common';
import { Component, computed, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { CustomerService } from '../service/customer.service';
import { Customer } from '../dto/Customer';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule,CommonModule,ReactiveFormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent implements OnInit {

  //email:string =''
  //password : string = ''
  message = ''
  status = false;

  form = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.minLength(2)]),
    password: new FormControl('', [Validators.required]),
    
  });

  ex = () => 0

  timeout = () => 0;
  
  constructor(private service: CustomerService,
            //injecting Router object to navigate it to new route
            private r : Router,
            //injecting ActivatedRoute
            private ar : ActivatedRoute
  ){}
  ngOnInit(): void {
    this.ar.queryParams.subscribe(
      params =>{ console.log(params)
            if(params['loggedOut'])
            {
              this.message = 'you have logged out'
            }

      }
    )
  }

  get f()
  {
    return this.form.controls
  }
  performLogin()
  {
    //let c = new Customer(this.email,this.password)
       
    let c = new Customer(this.form.value['email']+'',this.form.value['password']+'')
    console.log(c)
    //ONLY WHEN we subscribe() REST call is made
    this.service.login(c).subscribe({
      //next code is executed ONLY WHEN API returns SUCCESS
      next : success => {
        //this.message = 'login success'
        //this.status = true
        //console.log(success)//ONLY for debugging
        
        //save token securely for logged in of user
        this.service.saveToken(success.jwttoken);
        
        this.r.navigate(['accounts']) //navigating to next route
        
        const ii = setInterval(()=>{
          this.service.timeout.update(prev => prev - 1000)
        },100)

        let current:number = Date.now()
        console.log( this.service.timeout() - current )
        console.log(current)
        console.log(this.service.timeout())
        const i = setTimeout(()=>{alert('Session Expired. Login Again'); 
          clearInterval(i)
          this.service.deleteToken();
          this.r.navigate(['/login'],{queryParams:{loggedOut:'success'}})
        },this.service.timeout())
      },

      //error code is executed ONLY WHEN API returns ERROR
      error : e => {
         this.message = 'bad credentials'
         this.status = false
      }
    })

    /*
    if(this.service.login(c))
    {
      this.message = 'login success'
      this.status = true
    }
    else{
      this.message = 'bad credentials'
    }
      */
  }
}
