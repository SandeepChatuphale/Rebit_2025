import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Output } from '@angular/core';
import { FormControl, FormControlName, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-search',
  standalone: true,
  imports: [FormsModule,ReactiveFormsModule,CommonModule],
  templateUrl: './search.component.html',
  styleUrl: './search.component.css'
})
export class SearchComponent {

  search = 0

  searchReactive = new FormControl('searchReactive')

  @Output()
  searchEmitter = new EventEmitter<number>()

  searchAccount()
  {
    console.log(this.searchReactive)
    this.searchReactive.validator
    this.searchReactive.addValidators([Validators.required,Validators.min(4)])
    this.searchEmitter.emit(this.search)
  }
}
