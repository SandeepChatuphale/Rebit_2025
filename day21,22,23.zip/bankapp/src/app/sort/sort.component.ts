import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-sort',
  standalone: true,
  imports: [],
  templateUrl: './sort.component.html',
  styleUrl: './sort.component.css'
})
export class SortComponent {

  @Output()
  sortEmitter = new EventEmitter<string>()  //EventEmitter is built-in object

  accountsort(sortCriteria:string)
  {
    this.sortEmitter.emit(sortCriteria) //emit() is a built-in method of EventEmitter
  }
}
