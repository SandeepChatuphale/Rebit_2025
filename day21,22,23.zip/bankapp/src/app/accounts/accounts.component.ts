import { Component } from '@angular/core';
import { Account } from '../dto/Account';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AccountService } from '../service/account.service';
import { SortComponent } from '../sort/sort.component';
import { SearchComponent } from '../search/search.component';



@Component({
  selector: 'app-accounts',
  standalone: true,
  imports: [CommonModule,FormsModule,SortComponent,SearchComponent],
  templateUrl: './accounts.component.html',
  styleUrl: './accounts.component.css'
})
export class AccountsComponent {

    accounts : Account[] = [];
    copyAccounts : Account[] = [];

    flag : boolean= false
    message : string = '';

    serachCriteria : number = 0 ;

    successStyle = {color:'green',fontStyle:'italic'}
    errorStyle = {color:'red'}
    
    //DI - injecting object of service
    constructor(private s:AccountService){ 
      this.accounts = s.accounts;
      this.copyAccounts = s.accounts
    }

    //this method is called when user clicks on child component's
    //radio buttons
    sortData(sortType:string){
      this.accounts.sort((a1,a2)=>a1.balance - a2.balance)
    }

    searchAccount(balance:number)
    {
      console.log("balance " + balance)
      if(balance==null){
        this.accounts = this.copyAccounts
      }
      else
      this.accounts =  this.accounts.filter(a => a.balance > balance)
    }

    showAll(){
        this.s.findAll().subscribe({
          next:success => {
            this.accounts = success;
            this.copyAccounts = success
            
          
          }
        
        })
    }

    //invoked when user clicks on button
    //event binding
    deleteAccount(accN:number)
    {
    const status = confirm('are you sure?')
    if(status){
     // this.accounts =  this.accounts.filter(a => a.accountNumber != accN)
     this.s.deleteAccountById(accN).subscribe({
      next: success=>{
                this.message = 'Account Deleted with account Number ' + accN
                this.showAll()
                },
      error : e => {console.log(e); alert('oops') }
       })
     }
      else{
        this.message = 'Deletetion Cancelled'
      }
    }
}
