import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../service/customer.service';
import { Customer } from '../dto/Customer';
import { ActivatedRoute } from '@angular/router';
import { UpdateComponent } from '../update/update.component';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [UpdateComponent],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css'
})
export class ProfileComponent implements OnInit {

  authenticated = new Customer('','')

  constructor(private service : CustomerService,private ar : ActivatedRoute){
    this.showProfile()
  }
  ngOnInit(): void {
    this.ar.params.subscribe(
      params => {
        console.log(params)
      }
    )
  }

  showProfile()
  {
    this.authenticated = this.service.findProfileDetails()
  }

}
