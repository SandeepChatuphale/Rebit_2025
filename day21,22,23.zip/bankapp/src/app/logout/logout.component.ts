import { Component } from '@angular/core';
import { CustomerService } from '../service/customer.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-logout',
  standalone: true,
  imports: [],
  templateUrl: './logout.component.html',
  styleUrl: './logout.component.css'
})
export class LogoutComponent {

  constructor(private service : CustomerService,private r : Router){}

  confirmLogout()
  {
    const res = confirm('are you sure?')

    if(res)
    {
      this.service.deleteToken()

      //here loggedOut is custom query parameter name and you have logged out successfully
      //is its custom value
      this.r.navigate(['login'],{queryParams:{loggedOut:'you have logged out successfully'}})
    }

  }
}
