import { Component } from '@angular/core';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Account } from '../dto/Account';
import { AccountService } from '../service/account.service';


@Component({
  selector: 'app-account',
  standalone: true,
  imports: [FormsModule,ReactiveFormsModule],
  templateUrl: './account.component.html',
  styleUrl: './account.component.css'
})
export class AccountComponent {

  balance = new FormControl(112);
  owner = new FormControl('')
  a = new Account(0,0,'')

  constructor(private service : AccountService){}

  createNewAccount()
  {
    console.log(this.balance.value)
    
    let ac = new Account(0,this.a.balance,this.a.owner)
    //save it to repo 
    //this.service.save(ac)
  }
}
