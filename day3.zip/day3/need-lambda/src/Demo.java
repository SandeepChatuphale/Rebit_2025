import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

@FunctionalInterface
interface MyCondition<T>{	//generic interface
	boolean check(T o);
}
public class Demo {
	public static void main(String[] args) {
		List<String> cities = new ArrayList<>();
		cities.add("Mumbai");
		cities.add("Delhi");
		cities.add("Pune");
		cities.add("Nagpur");
		cities.add("Jaipur");	
		Demo d = new Demo();
		//d.printCitiesByLength(cities, 5);
		System.out.println("By name starts with");
		Predicate<String> c = (String city) -> city.startsWith("P");
		d.printByCondition(cities, c);
		System.out.println("By Length");
		//MyCondition<String> c2 = city -> city.length()>5;
		d.printByCondition(cities, city -> city.length()>5);	
	}	
	void printByCondition(List<String> cities,Predicate<String> c)
	{
		//loop to iterate over list
		for(String city : cities){
			if(c.test(city))//invoking lambda function
				System.out.println(city);
		}
		
		
	}
	void printCitiesByLength(List<String> cities , int len){
		//loop to iterate over list
		for(String city : cities){
			if(city.length() > len)
				System.out.println(city);
		}
	}
	void printCitiesByStartsWith(List<String> cities,String str)
	{
		//loop to iterate over list
				for(String city : cities){
					if(city.startsWith(str))
						System.out.println(city);
				}
	}
	
	
}
