import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class DemoLambds {

	public static void main(String[] args) {

		Predicate<String> p = str -> str.length() > 5;
		System.out.println(p.test("mumbai"));
		
		Function<String, Integer> f = str -> str.length();
		System.out.println(f.apply("mumbai"));
		
		Consumer<String> c = str -> System.out.println(str);
		c.accept("mumbai");
		
		Supplier<String> s = () -> "data";
		System.out.println(s.get());
		
		
		List<String> cities = new ArrayList<>();
		cities.add("Mumbai");
		cities.add("kolkata");
		
		
		cities.forEach(city -> System.out.println(city));
		
		//prior to jdk 8
		for (String city : cities) {
			System.out.println(city);
		}
		
		
	}

}