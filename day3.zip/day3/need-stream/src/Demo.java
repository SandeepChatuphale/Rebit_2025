import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Demo {
	public static void main(String[] args) {
		
		//source
		List<String> cities = new ArrayList<>();
		cities.add("Mumbai");
		cities.add("Delhi");
		cities.add("Pune");
		cities.add("Nagpur");
		cities.add("Jaipur");

		List<Integer> listOfLengths = cities.stream()
			  .map(city -> city.length())//intermediate operation
			  //.toList();//added in jdk 16
			  .collect(Collectors.toList());//this is prior to jdk 16
		
		System.out.println(listOfLengths);
			  
			  
		
		
		
		
		Demo d = new Demo();
		List<String> new_cities = d.findAllCitiesByPredicate(cities, 
											city -> city.length()>5);
		System.out.println(new_cities);//destination
		System.out.println(cities);//source remains unchanged
	}	
	
	//new way
	List<String> findAllCities(List<String> cities,Predicate<String> p)
	{
		//step1 - obtain stream from source
		//Stream<String> stream = cities.stream();
		
		//Step2 - intermediate operation
		//Stream<String> filteredStream = stream.filter(p);
		
		//step3 - terminal operation
		//List<String> list = filteredStream.toList();
		
		//recommended approach
		List<String> list = cities.stream()
								  .filter(p)
								  .toList();
		
		
		
		
		return list;
	}
	
	
	int findCountOfCitiesByPredicate(List<String> cities , Predicate<String> p)
	{
		//Stream<String> stream = cities.stream();
		//Stream<String> filteredStream = stream.filter(p);
		//long c = filteredStream.count();	//terminal operation
		//return (int) c;
		
		return (int)cities.stream()
						  .filter(p)
						  .count();
		
	}
	
	//old java way
	List<String> findAllCitiesByPredicate(List<String> cities,Predicate<String> p)
	{
		//Destination
		List<String> allCities = new ArrayList<>();		
		
		cities.forEach(c -> {
			if(p.test(c))//invoking lambda function
				allCities.add(c);
		});
		return allCities;
	}	
}