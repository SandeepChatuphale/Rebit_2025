

@FunctionalInterface	//recommended
interface Printable{
	void print();
}
interface CalculateTax{
	double calculate(double income);
}

interface Concat{
	String join(String s1,String s2);
}




public class DemoLambda {
	public static void main(String[] args) {
		
		//1
		CalculateTax c = (double income) -> {
			return 45.6;
		};
	
		//2
		//argument data type is optional
		CalculateTax c1 = (income) -> {return 45.6;};
		
		//3
		//if there is ONLY one argument
		//() is optional
		CalculateTax c2 = income -> {return 45.6;};
		
		
		//4
		CalculateTax c3 = income -> 45.6;
		
		
		
		//lambda expression
		Printable p = () -> System.out.println("In lambda");
				
		System.out.println(p);
		p.print();
		
		
	}

}
