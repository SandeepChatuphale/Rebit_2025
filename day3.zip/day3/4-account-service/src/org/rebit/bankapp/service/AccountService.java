package org.rebit.bankapp.service;

import java.util.List;

import org.rebit.bankapp.entity.Account;

public interface AccountService {

	Account register(Account a);
	Account searchByAccountNumber(int accountNumber);
	void deleteByAccountnumber(int accountNumber);
	List<Account> searchAll();	//implement 
	List<Account> searchAllEligibleForCreditCard(int amount);
	List<String> searchAllOwnersMaintainingBalance(int amount);
	double calculateTotalBalance();
}
